#pragma once

#include <avr/io.h>

uint8_t adc_read(int channel);