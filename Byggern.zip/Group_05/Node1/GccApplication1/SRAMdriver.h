#pragma once
#include <stdio.h>
#include <avr/io.h>

void SRAM_init(void);
void SRAM_test(void);