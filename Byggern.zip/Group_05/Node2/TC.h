/*
 * TC.h
 *
 * Created: 07.11.2023 17:54:59
 *  Author: kiennd
 */ 

#pragma once
#ifndef TC_H_
#define TC_H_

void timer_init(void);
void delay_ms(int delay);
void delay_us(int delay);

#endif /* TC_H_ */